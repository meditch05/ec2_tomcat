#!/bin/bash

### crontab example ###########################################
* * * * * /software/tomcat/shl/auto_restart.sh 1>/dev/null 2>&1
###############################################################

. ~/.bash_profile

SERVERS="aws_test "

for CON in ${SERVERS}
do
    LOG_DIR=/log_data/auto_restart
    RESTART_SEED=${LOG_DIR}/${CON}/seed
    LOG_FILE=${LOG_DIR}/${CON}_restart.log
    LOCK_SEED=${LOG_DIR}/${CON}_restart.lck
    LOCKCHK=`ls -al ${LOCK_SEED}     2> /dev/null | wc -l`
    FILECHK=`ls -al ${RESTART_SEED}  2> /dev/null | wc -l`

    if [ ${FILECHK} -eq 1 ] && [ ${LOCKCHK} -eq 0 ] ; then
        echo "" > ${LOG_FILE}
        mv ${RESTART_SEED} ${LOCK_SEED}

        echo "[`date +%Y%m%d.%H%M%S`] ${CON} - Seed File is Resolved and Restart Tomcat Instance." | tee -a ${LOG_FILE}

        /software/tomcat/servers/${CON}/shl/stop.sh; sleep 2;

        /software/tomcat/servers/${CON}/shl/start.sh
        START_RST=$?
        if [ ${START_RST} -ne 0 ]; then
            echo "[`date +%Y%m%d.%H%M%S`] ${CON} - Start Railed. Check catalina.out log!!"         | tee -a ${LOG_FILE}
        fi
        \rm -rf ${LOCK_SEED}
    else
        echo "[`date +%Y%m%d.%H%M%S`] ${CON} - no seed file or lock file exist"
    fi
done

exit 0
