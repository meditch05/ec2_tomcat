#!/bin/sh
SNAPSHOT_DIR=/home/webwas/dump
 
if [ ! -d ${SNAPSHOT_DIR} ]; then
   mkdir -p ${SNAPSHOT_DIR}
fi
 
NETSTAT_SNAPSHOT_FILE="${SNAPSHOT_DIR}/net_`hostname`_`date +'%Y%m%d_%H%M%S'`.log"
 
i=1
 
###################################################
# Logging Netstat Snapshot 25 times every 3 sec.
###################################################
while [ $i -le 25 ];
do
        echo "###################################################" >> ${NETSTAT_SNAPSHOT_FILE}
        echo "COUNT : $i" >> ${NETSTAT_SNAPSHOT_FILE}
        echo "DATE : `date +'%Y%m%d_%H%M%S'`" >> ${NETSTAT_SNAPSHOT_FILE}
        echo "###################################################" >> ${NETSTAT_SNAPSHOT_FILE}
        netstat -an >> ${NETSTAT_SNAPSHOT_FILE}
        echo >> ${NETSTAT_SNAPSHOT_FILE}
        echo "$i times done."
        i=$((i+1))
        sleep 3
done

echo "check netstat snapshot file ${NETSTAT_SNAPSHOT_FILE}"
