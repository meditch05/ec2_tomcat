#!/bin/bash

# Check parameter
if [ $# -ne 1 ]; then
   echo "Usage> create_server.sh \"SERVER_NAME\""
   exit 1;
fi

# ENV
SERVER_NAME=$1
CATALINA_HOME=/dbawork/tomcat
LOG_HOME=/dbawork/tomcat/servers/${SERVER_NAME}
AUTO_RESTART_HOME=/dbawork/tomcat/servers/${SERVER_NAME}/auto_restart

##############################
# Create Server Directory
##############################
_create_server()
{
    cd ${CATALINA_HOME}/servers
    SERVER_CHK_CNT=`ls -al | grep "${SERVER_NAME}" | wc -l`

    if [ ${SERVER_CHK_CNT} -eq 0 ] ; then
        # create server dir
        cp -Rp template ${SERVER_NAME}

        # create log dir & link
        mkdir -p ${LOG_HOME}
        mkdir -p ${LOG_HOME}/gclog
        mkdir -p ${LOG_HOME}/heapdump
        mkdir -p ${LOG_HOME}/temp

        ln -s  ${LOG_HOME} ${CATALINA_HOME}/servers/${SERVER_NAME}/logs

        # make auto_restart dir
        mkdir -p ${AUTO_RESTART_HOME}
        \chmod 770 ${AUTO_RESTART_HOME}

        # modify ${SERVER_NAME} in tomcat.env
        perl -pi -e "s/template/${SERVER_NAME}/g" ${CATALINA_HOME}/servers/${SERVER_NAME}/shl/tomcat.env
    else
        echo "The server specified is already exist"
        exit 1;
    fi
}

##############################
# Add New Server in log_del.sh & logrotate.cfg & start/stop/restart all script
##############################
_add_script()
{
    # log_del.sh / auto_restart.sh
    SVRS=`grep ^SERVERS ${CATALINA_HOME}/shl/log_del.sh | cut -d'"' -f2`
    perl -pi -e "s/SERVERS=\"${SVRS}/SERVERS=\"${SVRS}${SERVER_NAME} /g" ${CATALINA_HOME}/shl/log_del.sh
    perl -pi -e "s/SERVERS=\"${SVRS}/SERVERS=\"${SVRS}${SERVER_NAME} /g" ${CATALINA_HOME}/shl/auto_restart.sh

    # logrotate.cfg
    NEWLINE=`cat -n ${CATALINA_HOME}/shl/logrotate.cfg | grep "{" | awk '{print $1}'`
    awk -v newline=${NEWLINE} -v servername=${SERVER_NAME} '{ if (NR==newline) print "/dbawork/tomcat/servers/"servername"/catalina.out"; print $0}' ${CATALINA_HOME}/shl/logrotate.cfg \
    > ${CATALINA_HOME}/shl/logrotate.cfg.new
    mv ${CATALINA_HOME}/shl/logrotate.cfg.new ${CATALINA_HOME}/shl/logrotate.cfg

    # tomcat_start.sh
    NEWLINE=`cat -n ${CATALINA_HOME}/shl/tomcat_start.sh | grep "### check_web" | awk '{print $1}'`
    awk -v newline=${NEWLINE} -v servername=${SERVER_NAME} '{ if (NR==newline) print ""; print $0}' ${CATALINA_HOME}/shl/tomcat_start.sh > ${CATALINA_HOME}/shl/tomcat_start.sh.new
    awk -v newline=${NEWLINE} -v servername=${SERVER_NAME} '{ if (NR==newline) print "/dbawork/tomcat/servers/"servername"/shl/start.sh; sleep 3;"; print $0}' ${CATALINA_HOME}/shl/tomcat_start.sh.new \
    > ${CATALINA_HOME}/shl/tomcat_start.sh; \rm ${CATALINA_HOME}/shl/tomcat_start.sh.new

    # tomcat_restart.sh
    NEWLINE=`cat -n ${CATALINA_HOME}/shl/tomcat_restart.sh | grep "### check_web" | awk '{print $1}'`
    awk -v newline=${NEWLINE} -v servername=${SERVER_NAME} '{ if (NR==newline) print ""; print $0}' ${CATALINA_HOME}/shl/tomcat_restart.sh > ${CATALINA_HOME}/shl/tomcat_restart.sh.new
    awk -v newline=${NEWLINE} -v servername=${SERVER_NAME} '{ if (NR==newline) print "/dbawork/tomcat/servers/"servername"/shl/start.sh; sleep 3;"; print $0}' ${CATALINA_HOME}/shl/tomcat_restart.sh.new \
    > ${CATALINA_HOME}/shl/tomcat_restart.sh
    awk -v newline=${NEWLINE} -v servername=${SERVER_NAME} '{ if (NR==newline) print "/dbawork/tomcat/servers/"servername"/shl/stop.sh;  sleep 3;"; print $0}' ${CATALINA_HOME}/shl/tomcat_restart.sh \
    > ${CATALINA_HOME}/shl/tomcat_restart.sh.new; mv ${CATALINA_HOME}/shl/tomcat_restart.sh.new ${CATALINA_HOME}/shl/tomcat_restart.sh

    # tomcat_stop.sh
    echo "/dbawork/tomcat/servers/${SERVER_NAME}/shl/stop.sh;  sleep 3;" >> ${CATALINA_HOME}/shl/tomcat_stop.sh
    echo ""                                                               >> ${CATALINA_HOME}/shl/tomcat_stop.sh
}

##############################
# Add Crontab
##############################
_add_crontab()
{
    CHK=`crontab -l | grep -v "^#" | grep tomcat | grep "\/log_del.sh" | wc -l`
    if [ ${CHK} -eq 0 ]; then
        (crontab -l ; echo ""                                                                    ) | crontab -
        (crontab -l ; echo "################################################################"    ) | crontab -
        (crontab -l ; echo "# Tomcat Daily Log Delete"                                           ) | crontab -
        (crontab -l ; echo "################################################################"    ) | crontab -
        (crontab -l ; echo "0 0 * * * /dbawork/tomcat/shl/log_del.sh 1>/dev/null 2>&1"          ) | crontab -
    fi 

    CHK=`crontab -l | grep -v "^#" | grep "\/logrotate " | wc -l`
    if [ ${CHK} -eq 0 ]; then
        (crontab -l ; echo ""                                                                    ) | crontab -
        (crontab -l ; echo "################################################################"    ) | crontab -
        (crontab -l ; echo "# Tomcat Daily Log Rotate"                                           ) | crontab -
        (crontab -l ; echo "################################################################"    ) | crontab -
        (crontab -l ; echo "0 0 * * * /usr/sbin/logrotate -f /dbawork/tomcat/shl/logrotate.cfg 1>/dev/null 2>&1") | crontab -
    fi

    CHK=`crontab -l | grep -v "^#" | grep "\/web_mon_cron.sh" | wc -l`
    if [ ${CHK} -eq 0 ]; then
        (crontab -l ; echo ""                                                                    ) | crontab -
        (crontab -l ; echo "################################################################"    ) | crontab -
        (crontab -l ; echo "# Tomcat Monitoring"                                                 ) | crontab -
        (crontab -l ; echo "################################################################"    ) | crontab -
        (crontab -l ; echo "1-59/3 * * * * /home/webwas/shl/mon/web_mon_cron.sh 1>/dev/null 2>&1") | crontab -
    fi

    CHK=`crontab -l | grep -v "^#" | grep "\/dailychk.sh" | wc -l`
    if [ ${CHK} -eq 0 ]; then
        (crontab -l ; echo ""                                                                    ) | crontab -
        (crontab -l ; echo "################################################################"    ) | crontab -
        (crontab -l ; echo "# Daily Check"                                                       ) | crontab -
        (crontab -l ; echo "################################################################"    ) | crontab -
        (crontab -l ; echo "00 08 * * * /home/webwas/shl/mon/dailychk.sh     1>/dev/null 2>&1"   ) | crontab -
        (crontab -l ; echo "30 17 * * * /home/webwas/shl/mon/dailychk.sh     1>/dev/null 2>&1"   ) | crontab -
    fi
}

##############################
# Add New Server in Alias
##############################
_add_alias()
{
    SVR_CNT=`grep ^#SERVER_CNT ${CATALINA_HOME}/shl/alias.tomcat | cut -d'=' -f2`
    NEW_CNT=`expr ${SVR_CNT} + 1`

    perl -pi -e "s/SERVER_CNT=${SVR_CNT}/SERVER_CNT=${NEW_CNT}/g" ${CATALINA_HOME}/shl/alias.tomcat

    echo ""                                                                                                          >> ${CATALINA_HOME}/shl/alias.tomcat
    echo "alias  tcfg${NEW_CNT}='cd /dbawork/tomcat/servers/${SERVER_NAME}/conf;                    ls -l'"         >> ${CATALINA_HOME}/shl/alias.tomcat
    echo "alias  tdep${NEW_CNT}='cd /dbawork/tomcat/servers/${SERVER_NAME}/conf/Catalina/localhost; ls -l'"         >> ${CATALINA_HOME}/shl/alias.tomcat
    echo "alias  tshl${NEW_CNT}='cd /dbawork/tomcat/servers/${SERVER_NAME}/shl;                     ls -l'"         >> ${CATALINA_HOME}/shl/alias.tomcat
    echo "alias  tlog${NEW_CNT}='cd /dbawork/tomcat/servers/${SERVER_NAME};                   ls -lart | tail -30'"         >> ${CATALINA_HOME}/shl/alias.tomcat
    echo "alias talog${NEW_CNT}='tail -30f /dbawork/tomcat/servers/${SERVER_NAME}/localhost_access.\`date +%Y-%m-%d\`.log'" >> ${CATALINA_HOME}/shl/alias.tomcat
    echo "alias telog${NEW_CNT}='tail -30f /dbawork/tomcat/servers/${SERVER_NAME}/localhost.\`date +%Y-%m-%d\`.log'"        >> ${CATALINA_HOME}/shl/alias.tomcat
    echo "alias tclog${NEW_CNT}='tail -30f /dbawork/tomcat/servers/${SERVER_NAME}/catalina.out'"                            >> ${CATALINA_HOME}/shl/alias.tomcat

    grep -v "^#" ${CATALINA_HOME}/shl/alias.tomcat >> ${HOME}/.bash_profile
    perl -pi -e "s/^alias/#alias/g" ${CATALINA_HOME}/shl/alias.tomcat
    bash --init-file ${HOME}/.bash_profile
}

##############################
# main
##############################
main()
{
    _create_server
    _add_script
    _add_crontab
    _add_alias
}

main
